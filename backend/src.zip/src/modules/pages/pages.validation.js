import { z } from "zod";

// Registered system protection constraints
const RESERVED_SLUGS = [
  "admin", "api", "login", "register", "dashboard", 
  "cms", "uploads", "settings", "profile", "users",
  "home", "index", "404", "500", "menu"
];

// Dynamic system design layout templates routing blocks
export const ALLOWED_TEMPLATES = [
  "default",
  "landing-page",
  "service-page",
  "contact-page",
  "about-page",
  "ripple-page",
  "gulmo-page",
  "mandala-page",
  "prakriti-page",
  "workshop-page"
];

// ==== NEW TEMPLATE ENGINE KEYS ====
// Whenever we create a new template in frontend, add its key here
export const ALLOWED_TEMPLATE_KEYS = [
  "landing-basic",
  "landing-ripples"
];

const richTextBlockSchema = z.object({ type: z.literal("richText"), data: z.record(z.any()).default({}) });

const ripplesHeroBlockSchema = z.object({ type: z.literal("ripplesHero"), data: z.record(z.any()).default({}) });
const ripplesIntroBlockSchema = z.object({ type: z.literal("ripplesIntro"), data: z.record(z.any()).default({}) });
const ripplesNatureAquariumBlockSchema = z.object({ type: z.literal("ripplesNatureAquarium"), data: z.record(z.any()).default({}) });
const ripplesLetsBeginBlockSchema = z.object({ type: z.literal("ripplesLetsBegin"), data: z.record(z.any()).default({}) });
const ripplesGulmoLetsBeginBlockSchema = z.object({ type: z.literal("ripplesGulmoLetsBegin"), data: z.record(z.any()).default({}) });
const ripplesAquascapeBlockSchema = z.object({ type: z.literal("ripplesAquascape"), data: z.record(z.any()).default({}) });
const getStartedCtaBlockSchema = z.object({ type: z.literal("getStartedCta"), data: z.record(z.any()).default({}) });

// GULMO BLOCKS
const gulmoHeroBlockSchema = z.object({ type: z.literal("gulmoHero"), data: z.record(z.any()).default({}) });
const gulmoTerrariumBlockSchema = z.object({ type: z.literal("gulmoTerrarium"), data: z.record(z.any()).default({}) });
const gulmoQuoteBlockSchema = z.object({ type: z.literal("gulmoQuote"), data: z.record(z.any()).default({}) });
const gulmoForestOrganismBlockSchema = z.object({ type: z.literal("gulmoForestOrganism"), data: z.record(z.any()).default({}) });
const gulmoOurProjectsBlockSchema = z.object({ type: z.literal("gulmoOurProjects"), data: z.record(z.any()).default({}) });
const gulmoLetsBeginBlockSchema = z.object({ type: z.literal("gulmoLetsBegin"), data: z.record(z.any()).default({}) });
const gulmoConceptBlockSchema = z.object({ type: z.literal("gulmoConcept"), data: z.record(z.any()).default({}) });

// PRAKRITI LAB BLOCKS 
const prakritiHeroBlockSchema = z.object({ type: z.literal("prakritiHero"), data: z.record(z.any()).default({}) });
const prakritiIntroBlockSchema = z.object({ type: z.literal("prakritiIntro"), data: z.record(z.any()).default({}) });
const prakritiEducationBlockSchema = z.object({ type: z.literal("prakritiEducation"), data: z.record(z.any()).default({}) });
const prakritiUpcomingWorkshopsBlockSchema = z.object({ type: z.literal("prakritiUpcomingWorkshops"), data: z.record(z.any()).default({}) });
const prakritiLabExperienceBlockSchema = z.object({ type: z.literal("prakritiLabExperience"), data: z.record(z.any()).default({}) });
const prakritiLabShowcaseBlockSchema = z.object({ type: z.literal("prakritiLabShowcase"), data: z.record(z.any()).default({}) });
const prakritiGetInTouchBlockSchema = z.object({ type: z.literal("prakritiGetInTouch"), data: z.record(z.any()).default({}) });
const prakritiLetsBeginBlockSchema = z.object({ type: z.literal("prakritiLetsBegin"), data: z.record(z.any()).default({}) });

// WORKSHOP BLOCKS
const workshopHeroBlockSchema = z.object({ type: z.literal("workshopHero"), data: z.record(z.any()).default({}) });
const workshopDetailsBlockSchema = z.object({ type: z.literal("workshopDetails"), data: z.record(z.any()).default({}) });
const workshopGalleryBlockSchema = z.object({ type: z.literal("workshopGallery"), data: z.record(z.any()).default({}) });

// ABOUT BLOCK
const aboutHorizontalScrollBlockSchema = z.object({ type: z.literal("aboutHorizontalScroll"), data: z.record(z.any()).default({}) });

// MANDALA BLOCK
const mandalaHorizontalScrollBlockSchema = z.object({ type: z.literal("mandalaHorizontalScroll"), data: z.record(z.any()).default({}) });

// PROJECTS BANNER BLOCK
const projectsBannerBlockSchema = z.object({ type: z.literal("projectsBanner"), data: z.record(z.any()).default({}) });

const contactFormBlockSchema = z.object({
  type: z.literal("contactForm"),
  data: z.object({
    isVisible: z.boolean().optional(),
    formSlug: z.string().optional().nullable(),
    formTitle: z.string().trim().max(150).optional().nullable()
  }).catchall(z.any()).default({})
});

const dynamicButtonBlockSchema = z.object({ 
  type: z.literal("dynamicButton"), 
  data: z.record(z.any()).default({}) 
});

const blockSchema = z.discriminatedUnion("type", [
  richTextBlockSchema,
  contactFormBlockSchema,
  dynamicButtonBlockSchema,
  ripplesHeroBlockSchema,
  ripplesIntroBlockSchema,
  ripplesNatureAquariumBlockSchema,
  ripplesLetsBeginBlockSchema,
  ripplesGulmoLetsBeginBlockSchema,
  ripplesAquascapeBlockSchema,
  getStartedCtaBlockSchema,
  // Gulmo Blocks
  gulmoHeroBlockSchema,
  gulmoTerrariumBlockSchema,
  gulmoQuoteBlockSchema,
  gulmoForestOrganismBlockSchema,
  gulmoOurProjectsBlockSchema,
  gulmoLetsBeginBlockSchema,
  gulmoConceptBlockSchema,
  // PRAKRITI LAB BLOCKS
  prakritiHeroBlockSchema,
  prakritiIntroBlockSchema,
  prakritiEducationBlockSchema,
  prakritiUpcomingWorkshopsBlockSchema,
  prakritiLabExperienceBlockSchema,
  prakritiLabShowcaseBlockSchema,
  prakritiGetInTouchBlockSchema,
  prakritiLetsBeginBlockSchema,
  // WORKSHOP BLOCKS
  workshopHeroBlockSchema,
  workshopDetailsBlockSchema,
  workshopGalleryBlockSchema,
  // ABOUT BLOCK
  aboutHorizontalScrollBlockSchema,
  // MANDALA BLOCK
  mandalaHorizontalScrollBlockSchema,
  // PROJECTS BANNER BLOCK
  projectsBannerBlockSchema,
]);

const pageContentSchema = z.object({
  blocks: z.array(blockSchema).default([]),
}).catchall(z.any()).default({ blocks: [] });


// ==== REUSABLE PUBLISH VALIDATION LOGIC ====
const publishValidationRules = (data, ctx) => {
  if (data.status === "PUBLISHED") {
    // If it's a NEW Template Engine page
    if (data.templateKey) {
      if (!ALLOWED_TEMPLATE_KEYS.includes(data.templateKey)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `Cannot publish: '${data.templateKey}' is not a valid registered template.`,
          path: ["templateKey"]
        });
      }
      if (!data.templateVersion) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Cannot publish: Template version is required for modern templates.",
          path: ["templateVersion"]
        });
      }
      if (!data.content || Object.keys(data.content).length === 0 || (data.content.blocks && data.content.blocks.length === 0 && Object.keys(data.content).length === 1)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Cannot publish: Content cannot be empty.",
          path: ["content"]
        });
      }
    } 
    // If it's a LEGACY NatureCube page
    else {
      if (!data.content || !Array.isArray(data.content.blocks) || data.content.blocks.length === 0) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Cannot publish: Legacy page requires at least one content block.",
          path: ["content"]
        });
      }
    }
  }
};


// ==== BASE SCHEMA OBJECT (WITHOUT REFINEMENTS) ====
// We define the base object first so we can reuse it for partial updates safely
const basePageSchemaObject = z.object({
  title: z.string().trim().min(1, "Title is required").max(150, "Title cannot exceed 150 characters"),
  
  slug: z.string().trim().toLowerCase()
    .regex(/^[a-z0-9-\/]+$/, "Slug can only contain lowercase letters, numbers, dashes, and slashes")
    .max(150, "Slug cannot exceed 150 characters")
    .refine((slug) => !RESERVED_SLUGS.includes(slug), {
      message: "This slug is reserved by the system and cannot be used.",
    })
    .optional()
    .nullable(),
    
  excerpt: z.string().trim().max(1000, "Excerpt cannot exceed 1000 characters").optional().nullable(),
  content: pageContentSchema,
  status: z.enum(["DRAFT", "PUBLISHED", "SCHEDULED"]).default("DRAFT").optional(),
  scheduledUpdateAt: z.string().datetime({ message: "Invalid ISO-8601 datetime format" }).optional().nullable(),
  scheduledUpdateData: z.any().optional().nullable(),
  
  template: z.enum(ALLOWED_TEMPLATES, {
    errorMap: () => ({ message: "Selected layout design template is not registered or supported by system." })
  }).default("default").optional(),

  templateKey: z.string().max(100).optional().nullable(),
  templateVersion: z.number().int().optional().nullable(),

  parentId: z.string().cuid("Invalid Parent ID structural trace context format identifier").optional().nullable(),
  menuOrder: z.coerce.number().int("Menu display re-ordering parameter metrics must remain a valid integer").default(0).optional(),
  showInMenu: z.boolean().default(true).optional(),
  
  metaTitle: z.string().trim().max(100, "Meta title cannot exceed 100 characters").optional().nullable(),
  metaDescription: z.string().trim().max(500, "Meta description cannot exceed 500 characters").optional().nullable(),
  metaKeywords: z.string().trim().max(300, "Meta keywords cannot exceed 300 characters").optional().nullable(),
  
  featuredImageId: z.string().cuid("Invalid Media Asset digital asset cryptographic unique identity mapping").optional().nullable(),

  includeInSitemap: z.boolean().default(true).optional(),
  noIndex: z.boolean().default(false).optional(),
  noFollow: z.boolean().default(false).optional(),
  canonicalUrl: z.union([z.string().trim().url("Invalid canonical URL format."), z.literal("")]).optional().nullable(),
  ogTitle: z.string().trim().max(150).optional().nullable(),
  ogDescription: z.string().trim().max(500).optional().nullable(),
  ogImageId: z.union([z.string().cuid("Invalid OG Image ID format."), z.literal("")]).optional().nullable(),
});

// ==== API REQUEST PAYLOAD VALIDATION SCHEMAS ====

export const createPageSchema = basePageSchemaObject
  .strict()
  .superRefine(publishValidationRules);

export const updatePageSchema = basePageSchemaObject
  .partial()
  .extend({
    status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED", "SCHEDULED"]).optional(),
  })
  .strict()
  .superRefine(publishValidationRules);

// Admin Filter Matrix & Pagination Configuration Management Schema Lookups
export const pageQuerySchema = z.object({
  page: z.coerce.number().int().min(1, "Page tracking parameter must remain greater than 0").default(1),
  limit: z.coerce.number().int().min(1, "Pagination capacity constraint limit must register at least 1 data node").max(100, "Maximum network extraction block limit is capped at 100 records buffer").default(10),
  search: z.string().trim().optional(),
  status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED", "SCHEDULED"]).optional(),
  template: z.enum(ALLOWED_TEMPLATES).optional(), 
  authorId: z.string().cuid("Invalid corporate author query sequence filter constraint token").optional(),
  parentId: z.string().cuid("Invalid branch structural parent filter query identity token parameter").optional().nullable(), 
  sortBy: z.enum(["createdAt", "updatedAt", "publishedAt", "title", "menuOrder"]).default("createdAt"),
  sortOrder: z.enum(["asc", "desc"]).default("desc"),
});

export const pageIdParamSchema = z.object({
  id: z.string().cuid("Invalid cryptographic database record or unique execution structural transaction identifier identity format mapped"),
});

export const pageSlugParamSchema = z.object({
  slug: z.string().min(1, "Absolute layout path relative network resource endpoint tracking resource tracking signature processing failed"),
});

export const pageRevisionParamSchema = z.object({
  id: z.string().cuid("Invalid relational Page context unique validation model master layout ID template mapping token"),
  revisionId: z.string().cuid("Invalid historical version revision database checkpoint identifier cryptographic targeted snapshot identity token format")
});